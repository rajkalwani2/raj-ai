
  # AI Traffic Management System

  This is a code bundle for AI Traffic Management System. The original project is available at https://www.figma.com/design/B7FDV5mFH11j2Ya7DP5kHp/AI-Traffic-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  