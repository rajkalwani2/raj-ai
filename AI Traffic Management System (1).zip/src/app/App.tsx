import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { TrafficMap } from './components/TrafficMap';
import { CameraFeeds } from './components/CameraFeeds';
import { SignalController } from './components/SignalController';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { AIRecommendations } from './components/AIRecommendations';
import { AlertSystem } from './components/AlertSystem';
import { 
  Navigation, 
  Camera, 
  Car, 
  BarChart3, 
  Brain, 
  Bell, 
  Settings,
  Activity,
  Clock,
  TrendingDown,
  CheckCircle
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg">
                <Car className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">AI Traffic Management System</h1>
                <p className="text-sm text-muted-foreground">Urban Traffic Optimization Dashboard</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-sm">System Online</span>
              </div>
              <Badge variant="outline" className="flex items-center gap-1 bg-green-50 border-green-200 text-green-700">
                <Activity className="w-3 h-3 text-green-600" />
                5 Intersections Active
              </Badge>
              <Settings className="w-5 h-5 text-muted-foreground cursor-pointer hover:text-foreground" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Navigation className="w-4 h-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="cameras" className="flex items-center gap-2">
              <Camera className="w-4 h-4" />
              Cameras
            </TabsTrigger>
            <TabsTrigger value="signals" className="flex items-center gap-2">
              <Car className="w-4 h-4" />
              Signals
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              AI Insights
            </TabsTrigger>
            <TabsTrigger value="alerts" className="flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Alerts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-600">Avg Commute Time</p>
                      <p className="text-2xl font-bold text-blue-900">23.4 min</p>
                      <p className="text-xs text-green-600 flex items-center gap-1">
                        <TrendingDown className="w-3 h-3" />
                        -10.2% from target
                      </p>
                    </div>
                    <div className="p-3 bg-blue-500 rounded-full">
                      <Clock className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200 shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600">System Efficiency</p>
                      <p className="text-2xl font-bold text-green-900">78.6%</p>
                      <p className="text-xs text-green-600 flex items-center gap-1">
                        <TrendingDown className="w-3 h-3" />
                        +12.3% improvement
                      </p>
                    </div>
                    <div className="p-3 bg-green-500 rounded-full">
                      <Activity className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-600">Active Signals</p>
                      <p className="text-2xl font-bold text-purple-900">5/5</p>
                      <p className="text-xs text-green-600 flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        All operational
                      </p>
                    </div>
                    <div className="p-3 bg-purple-500 rounded-full">
                      <Car className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200 shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-orange-600">Live Cameras</p>
                      <p className="text-2xl font-bold text-orange-900">4/4</p>
                      <p className="text-xs text-green-600 flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        All online
                      </p>
                    </div>
                    <div className="p-3 bg-orange-500 rounded-full">
                      <Camera className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Overview Content */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-6">
                <TrafficMap />
              </div>
              <div className="space-y-6">
                <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-200 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-purple-700">
                      <div className="p-2 bg-purple-500 rounded-lg">
                        <Brain className="w-5 h-5 text-white" />
                      </div>
                      AI System Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span>Traffic Pattern Recognition</span>
                        <Badge className="bg-purple-500 text-white">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Predictive Analytics</span>
                        <Badge className="bg-blue-500 text-white">Running</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Optimization Engine</span>
                        <Badge className="bg-green-500 text-white">Optimizing</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Real-time Monitoring</span>
                        <Badge className="bg-orange-500 text-white">Online</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-amber-700">
                      <div className="p-2 bg-amber-500 rounded-lg">
                        <Bell className="w-5 h-5 text-white" />
                      </div>
                      Recent Alerts
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 border border-yellow-200 rounded-lg bg-yellow-50 hover:bg-yellow-100 transition-colors">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-yellow-800">Signal Optimization Available</p>
                          <p className="text-xs text-yellow-600">Broadway & 2nd Ave - 2 min ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 border border-green-200 rounded-lg bg-green-50 hover:bg-green-100 transition-colors">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800">Traffic Flow Normalized</p>
                          <p className="text-xs text-green-600">Oak St & 3rd Ave - 5 min ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 border border-blue-200 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors">
                        <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-blue-800">AI Learning Update</p>
                          <p className="text-xs text-blue-600">System-wide - 10 min ago</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="cameras">
            <CameraFeeds />
          </TabsContent>

          <TabsContent value="signals">
            <SignalController />
          </TabsContent>

          <TabsContent value="analytics">
            <AnalyticsPanel />
          </TabsContent>

          <TabsContent value="ai">
            <AIRecommendations />
          </TabsContent>

          <TabsContent value="alerts">
            <AlertSystem />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-gradient-to-r from-slate-100 to-slate-200 mt-12 shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              © 2024 AI Traffic Management System. Reducing urban congestion through intelligent optimization.
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Last Update: {new Date().toLocaleTimeString()}</span>
              <span>•</span>
              <span>System Health: Optimal</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}