import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { MapPin, Navigation, AlertTriangle, CheckCircle } from 'lucide-react';

interface Intersection {
  id: string;
  name: string;
  x: number;
  y: number;
  status: 'normal' | 'congested' | 'critical';
  signalTiming: {
    north: number;
    south: number;
    east: number;
    west: number;
  };
  trafficFlow: number;
  waitTime: number;
}

const mockIntersections: Intersection[] = [
  {
    id: '1',
    name: 'Main St & 1st Ave',
    x: 200,
    y: 150,
    status: 'normal',
    signalTiming: { north: 45, south: 45, east: 30, west: 30 },
    trafficFlow: 85,
    waitTime: 2.3
  },
  {
    id: '2',
    name: 'Broadway & 2nd Ave',
    x: 350,
    y: 100,
    status: 'congested',
    signalTiming: { north: 60, south: 60, east: 25, west: 25 },
    trafficFlow: 142,
    waitTime: 4.7
  },
  {
    id: '3',
    name: 'Oak St & 3rd Ave',
    x: 500,
    y: 200,
    status: 'critical',
    signalTiming: { north: 70, south: 70, east: 20, west: 20 },
    trafficFlow: 198,
    waitTime: 8.2
  },
  {
    id: '4',
    name: 'Pine St & Center',
    x: 150,
    y: 300,
    status: 'normal',
    signalTiming: { north: 40, south: 40, east: 35, west: 35 },
    trafficFlow: 67,
    waitTime: 1.8
  },
  {
    id: '5',
    name: 'Elm St & Park Ave',
    x: 400,
    y: 280,
    status: 'congested',
    signalTiming: { north: 55, south: 55, east: 30, west: 30 },
    trafficFlow: 156,
    waitTime: 5.1
  }
];

export function TrafficMap() {
  const [selectedIntersection, setSelectedIntersection] = useState<Intersection | null>(null);
  const [intersections, setIntersections] = useState(mockIntersections);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setIntersections(prev => prev.map(intersection => ({
        ...intersection,
        trafficFlow: Math.max(20, intersection.trafficFlow + (Math.random() - 0.5) * 20),
        waitTime: Math.max(0.5, intersection.waitTime + (Math.random() - 0.5) * 2),
        status: intersection.trafficFlow > 180 ? 'critical' : 
                intersection.trafficFlow > 120 ? 'congested' : 'normal'
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return '#22c55e';
      case 'congested': return '#f59e0b';
      case 'critical': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'normal': return <CheckCircle className="w-4 h-4" />;
      case 'congested': return <AlertTriangle className="w-4 h-4" />;
      case 'critical': return <AlertTriangle className="w-4 h-4" />;
      default: return <MapPin className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-emerald-700">
            <div className="p-2 bg-emerald-500 rounded-lg">
              <Navigation className="w-5 h-5 text-white" />
            </div>
            Traffic Network Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative bg-gradient-to-br from-slate-100 to-slate-200 rounded-lg p-4 h-96 overflow-hidden border border-slate-300">
            {/* Street Grid */}
            <svg className="absolute inset-0 w-full h-full">
              {/* Horizontal streets */}
              <line x1="0" y1="150" x2="600" y2="150" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
              <line x1="0" y1="200" x2="600" y2="200" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
              <line x1="0" y1="280" x2="600" y2="280" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
              
              {/* Vertical streets */}
              <line x1="200" y1="0" x2="200" y2="400" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
              <line x1="350" y1="0" x2="350" y2="400" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
              <line x1="500" y1="0" x2="500" y2="400" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
            </svg>
            
            {/* Intersections */}
            {intersections.map((intersection) => (
              <div
                key={intersection.id}
                className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2"
                style={{ left: intersection.x, top: intersection.y }}
                onClick={() => setSelectedIntersection(intersection)}
              >
                <div 
                  className="w-8 h-8 rounded-full border-3 border-white shadow-xl flex items-center justify-center ring-2 ring-white/50 hover:scale-110 transition-transform"
                  style={{ backgroundColor: getStatusColor(intersection.status) }}
                >
                  <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
                </div>
                
                {/* Traffic flow indicator */}
                <div className="absolute -top-10 left-1/2 transform -translate-x-1/2">
                  <Badge className="text-xs px-2 py-1 bg-slate-800 text-white shadow-lg">
                    {Math.round(intersection.trafficFlow)}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
          
          {/* Legend */}
          <div className="flex gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-sm">Normal</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <span className="text-sm">Congested</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span className="text-sm">Critical</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Intersection Details */}
      {selectedIntersection && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getStatusIcon(selectedIntersection.status)}
              {selectedIntersection.name}
              <Badge variant={selectedIntersection.status === 'critical' ? 'destructive' : 
                           selectedIntersection.status === 'congested' ? 'secondary' : 'default'}>
                {selectedIntersection.status}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{Math.round(selectedIntersection.trafficFlow)}</div>
                <div className="text-sm text-muted-foreground">Vehicles/Hour</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{selectedIntersection.waitTime.toFixed(1)}s</div>
                <div className="text-sm text-muted-foreground">Avg Wait Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{selectedIntersection.signalTiming.north}s</div>
                <div className="text-sm text-muted-foreground">N/S Green Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{selectedIntersection.signalTiming.east}s</div>
                <div className="text-sm text-muted-foreground">E/W Green Time</div>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button size="sm" variant="outline">
                Optimize Timing
              </Button>
              <Button size="sm" variant="outline">
                View Camera
              </Button>
              <Button size="sm" variant="outline">
                Manual Override
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}