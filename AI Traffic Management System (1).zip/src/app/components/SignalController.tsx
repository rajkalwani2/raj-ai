import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { Switch } from './ui/switch';
import { 
  Car, 
  Play, 
  Pause, 
  RotateCcw, 
  Settings, 
  AlertTriangle,
  Clock,
  Zap
} from 'lucide-react';

interface TrafficLight {
  id: string;
  intersection: string;
  currentPhase: 'north-south' | 'east-west' | 'pedestrian' | 'all-red';
  timeRemaining: number;
  isManual: boolean;
  cycles: {
    northSouth: number;
    eastWest: number;
    pedestrian: number;
    allRed: number;
  };
  efficiency: number;
  status: 'normal' | 'warning' | 'error';
}

const mockTrafficLights: TrafficLight[] = [
  {
    id: 'tl-01',
    intersection: 'Main St & 1st Ave',
    currentPhase: 'north-south',
    timeRemaining: 23,
    isManual: false,
    cycles: { northSouth: 45, eastWest: 30, pedestrian: 15, allRed: 3 },
    efficiency: 87,
    status: 'normal'
  },
  {
    id: 'tl-02',
    intersection: 'Broadway & 2nd Ave',
    currentPhase: 'east-west',
    timeRemaining: 12,
    isManual: true,
    cycles: { northSouth: 60, eastWest: 25, pedestrian: 12, allRed: 3 },
    efficiency: 72,
    status: 'warning'
  },
  {
    id: 'tl-03',
    intersection: 'Oak St & 3rd Ave',
    currentPhase: 'all-red',
    timeRemaining: 2,
    isManual: false,
    cycles: { northSouth: 70, eastWest: 20, pedestrian: 10, allRed: 5 },
    efficiency: 45,
    status: 'error'
  },
  {
    id: 'tl-04',
    intersection: 'Pine St & Center',
    currentPhase: 'pedestrian',
    timeRemaining: 8,
    isManual: false,
    cycles: { northSouth: 40, eastWest: 35, pedestrian: 15, allRed: 3 },
    efficiency: 92,
    status: 'normal'
  }
];

export function SignalController() {
  const [trafficLights, setTrafficLights] = useState(mockTrafficLights);
  const [selectedLight, setSelectedLight] = useState<string | null>(null);
  const [isSystemActive, setIsSystemActive] = useState(true);

  useEffect(() => {
    if (!isSystemActive) return;

    const interval = setInterval(() => {
      setTrafficLights(prev => prev.map(light => {
        if (light.isManual) return light;

        let newTimeRemaining = light.timeRemaining - 1;
        let newPhase = light.currentPhase;

        if (newTimeRemaining <= 0) {
          switch (light.currentPhase) {
            case 'north-south':
              newPhase = 'all-red';
              newTimeRemaining = light.cycles.allRed;
              break;
            case 'all-red':
              newPhase = light.currentPhase === 'north-south' ? 'east-west' : 'north-south';
              newTimeRemaining = newPhase === 'east-west' ? light.cycles.eastWest : light.cycles.northSouth;
              break;
            case 'east-west':
              newPhase = 'pedestrian';
              newTimeRemaining = light.cycles.pedestrian;
              break;
            case 'pedestrian':
              newPhase = 'north-south';
              newTimeRemaining = light.cycles.northSouth;
              break;
          }
        }

        return {
          ...light,
          currentPhase: newPhase,
          timeRemaining: newTimeRemaining,
          efficiency: Math.max(30, Math.min(100, light.efficiency + (Math.random() - 0.5) * 5))
        };
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, [isSystemActive]);

  const getPhaseColor = (phase: string) => {
    switch (phase) {
      case 'north-south':
      case 'east-west':
        return '#10b981';
      case 'pedestrian':
        return '#3b82f6';
      case 'all-red':
        return '#ef4444';
      default:
        return '#6b7280';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'default';
      case 'warning': return 'secondary';
      case 'error': return 'destructive';
      default: return 'outline';
    }
  };

  const toggleManualMode = (lightId: string) => {
    setTrafficLights(prev => prev.map(light => 
      light.id === lightId 
        ? { ...light, isManual: !light.isManual }
        : light
    ));
  };

  const updateCycleTiming = (lightId: string, phase: keyof TrafficLight['cycles'], value: number) => {
    setTrafficLights(prev => prev.map(light => 
      light.id === lightId 
        ? { ...light, cycles: { ...light.cycles, [phase]: value } }
        : light
    ));
  };

  const forcePhaseChange = (lightId: string, newPhase: TrafficLight['currentPhase']) => {
    setTrafficLights(prev => prev.map(light => 
      light.id === lightId 
        ? { 
            ...light, 
            currentPhase: newPhase,
            timeRemaining: light.cycles[newPhase === 'north-south' ? 'northSouth' : 
                                      newPhase === 'east-west' ? 'eastWest' :
                                      newPhase === 'pedestrian' ? 'pedestrian' : 'allRed']
          }
        : light
    ));
  };

  return (
    <div className="space-y-4">
      {/* System Control */}
      <Card className="bg-gradient-to-br from-violet-50 to-purple-50 border-violet-200 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-violet-700">
              <div className="p-2 bg-violet-500 rounded-lg">
                <Car className="w-5 h-5 text-white" />
              </div>
              Signal Control System
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm">System Active</span>
                <Switch 
                  checked={isSystemActive}
                  onCheckedChange={setIsSystemActive}
                />
              </div>
              <Button size="sm" variant="outline">
                <Settings className="w-4 h-4" />
                System Settings
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-slate-100 to-slate-200 rounded-lg">
              <div className="text-2xl font-bold text-slate-700">{trafficLights.length}</div>
              <div className="text-sm text-slate-600">Total Signals</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-green-100 to-green-200 rounded-lg">
              <div className="text-2xl font-bold text-green-700">
                {trafficLights.filter(l => l.status === 'normal').length}
              </div>
              <div className="text-sm text-green-600">Online</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-lg">
              <div className="text-2xl font-bold text-yellow-700">
                {trafficLights.filter(l => l.status === 'warning').length}
              </div>
              <div className="text-sm text-yellow-600">Warnings</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-red-100 to-red-200 rounded-lg">
              <div className="text-2xl font-bold text-red-700">
                {trafficLights.filter(l => l.status === 'error').length}
              </div>
              <div className="text-sm text-red-600">Errors</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Traffic Light Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {trafficLights.map((light) => (
          <Card 
            key={light.id}
            className={`cursor-pointer transition-all hover:shadow-lg hover:scale-105 bg-white/80 backdrop-blur-sm ${
              selectedLight === light.id ? 'ring-2 ring-violet-500 shadow-lg' : 'border-violet-200'
            }`}
            onClick={() => setSelectedLight(selectedLight === light.id ? null : light.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{light.intersection}</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant={getStatusColor(light.status)}>
                    {light.status}
                  </Badge>
                  {light.isManual && (
                    <Badge variant="outline">Manual</Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Traffic Light Visualization */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="flex flex-col gap-2 p-2 bg-gray-900 rounded-lg">
                    <div className={`w-4 h-4 rounded-full border-2 border-gray-700 ${
                      light.currentPhase === 'north-south' || light.currentPhase === 'east-west' 
                        ? 'bg-green-400 shadow-lg shadow-green-400/50' : 'bg-gray-600'
                    }`} />
                    <div className={`w-4 h-4 rounded-full border-2 border-gray-700 ${
                      light.currentPhase === 'pedestrian' 
                        ? 'bg-yellow-400 shadow-lg shadow-yellow-400/50' : 'bg-gray-600'
                    }`} />
                    <div className={`w-4 h-4 rounded-full border-2 border-gray-700 ${
                      light.currentPhase === 'all-red' 
                        ? 'bg-red-400 shadow-lg shadow-red-400/50' : 'bg-gray-600'
                    }`} />
                  </div>
                  <div>
                    <div className="font-medium capitalize">
                      {light.currentPhase.replace('-', ' ')}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {light.timeRemaining}s remaining
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-lg font-bold">{light.efficiency}%</div>
                  <div className="text-sm text-muted-foreground">Efficiency</div>
                </div>
              </div>

              {/* Quick Controls */}
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleManualMode(light.id);
                  }}
                >
                  {light.isManual ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  {light.isManual ? 'Auto' : 'Manual'}
                </Button>
                
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    // Force cycle to next phase
                    const phases: TrafficLight['currentPhase'][] = ['north-south', 'east-west', 'pedestrian', 'all-red'];
                    const currentIndex = phases.indexOf(light.currentPhase);
                    const nextPhase = phases[(currentIndex + 1) % phases.length];
                    forcePhaseChange(light.id, nextPhase);
                  }}
                >
                  <RotateCcw className="w-4 h-4" />
                  Next
                </Button>
                
                {light.status === 'error' && (
                  <Button size="sm" variant="destructive">
                    <AlertTriangle className="w-4 h-4" />
                    Reset
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed Control Panel */}
      {selectedLight && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Advanced Controls - {trafficLights.find(l => l.id === selectedLight)?.intersection}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const light = trafficLights.find(l => l.id === selectedLight);
              if (!light) return null;

              return (
                <div className="space-y-6">
                  {/* Phase Timing Controls */}
                  <div>
                    <h4 className="font-medium mb-4 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Phase Timing (seconds)
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">North-South Green: {light.cycles.northSouth}s</label>
                        <Slider
                          value={[light.cycles.northSouth]}
                          onValueChange={([value]) => updateCycleTiming(light.id, 'northSouth', value)}
                          min={15}
                          max={120}
                          step={5}
                          className="w-full"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">East-West Green: {light.cycles.eastWest}s</label>
                        <Slider
                          value={[light.cycles.eastWest]}
                          onValueChange={([value]) => updateCycleTiming(light.id, 'eastWest', value)}
                          min={15}
                          max={120}
                          step={5}
                          className="w-full"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Pedestrian: {light.cycles.pedestrian}s</label>
                        <Slider
                          value={[light.cycles.pedestrian]}
                          onValueChange={([value]) => updateCycleTiming(light.id, 'pedestrian', value)}
                          min={5}
                          max={30}
                          step={1}
                          className="w-full"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">All Red: {light.cycles.allRed}s</label>
                        <Slider
                          value={[light.cycles.allRed]}
                          onValueChange={([value]) => updateCycleTiming(light.id, 'allRed', value)}
                          min={1}
                          max={10}
                          step={1}
                          className="w-full"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Manual Phase Control */}
                  <div>
                    <h4 className="font-medium mb-4 flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      Manual Phase Control
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      <Button
                        variant={light.currentPhase === 'north-south' ? 'default' : 'outline'}
                        onClick={() => forcePhaseChange(light.id, 'north-south')}
                        disabled={!light.isManual}
                      >
                        N/S Green
                      </Button>
                      <Button
                        variant={light.currentPhase === 'east-west' ? 'default' : 'outline'}
                        onClick={() => forcePhaseChange(light.id, 'east-west')}
                        disabled={!light.isManual}
                      >
                        E/W Green
                      </Button>
                      <Button
                        variant={light.currentPhase === 'pedestrian' ? 'default' : 'outline'}
                        onClick={() => forcePhaseChange(light.id, 'pedestrian')}
                        disabled={!light.isManual}
                      >
                        Pedestrian
                      </Button>
                      <Button
                        variant={light.currentPhase === 'all-red' ? 'destructive' : 'outline'}
                        onClick={() => forcePhaseChange(light.id, 'all-red')}
                        disabled={!light.isManual}
                      >
                        All Red
                      </Button>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-4 border-t">
                    <Button variant="outline">Save Configuration</Button>
                    <Button variant="outline">Load Preset</Button>
                    <Button variant="outline">Export Settings</Button>
                    <Button variant="secondary">Apply AI Optimization</Button>
                  </div>
                </div>
              );
            })()}
          </CardContent>
        </Card>
      )}
    </div>
  );
}