import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Brain, 
  Lightbulb, 
  TrendingUp, 
  Clock, 
  AlertTriangle, 
  CheckCircle,
  Zap,
  Target,
  Cpu,
  RefreshCw
} from 'lucide-react';

interface AIRecommendation {
  id: string;
  type: 'optimization' | 'prediction' | 'alert' | 'maintenance';
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  impact: {
    timeReduction: number;
    efficiencyGain: number;
    costSaving: number;
  };
  confidence: number;
  location: string;
  status: 'pending' | 'applied' | 'rejected';
  estimatedImplementationTime: string;
  aiReasoning: string;
}

const mockRecommendations: AIRecommendation[] = [
  {
    id: 'rec-001',
    type: 'optimization',
    priority: 'high',
    title: 'Optimize Broadway & 2nd Ave Signal Timing',
    description: 'Increase north-south green time by 15 seconds and reduce east-west by 10 seconds during peak hours.',
    impact: {
      timeReduction: 12.5,
      efficiencyGain: 18.3,
      costSaving: 2500
    },
    confidence: 89,
    location: 'Broadway & 2nd Ave',
    status: 'pending',
    estimatedImplementationTime: '2 minutes',
    aiReasoning: 'Historical data shows consistent north-south congestion during 7-9 AM. Vehicle queue analysis indicates optimal timing adjustment.'
  },
  {
    id: 'rec-002',
    type: 'prediction',
    priority: 'medium',
    title: 'Predicted Congestion at Oak St & 3rd Ave',
    description: 'Heavy traffic expected in 30 minutes due to nearby event. Pre-adjust signal timing.',
    impact: {
      timeReduction: 8.2,
      efficiencyGain: 12.1,
      costSaving: 1200
    },
    confidence: 76,
    location: 'Oak St & 3rd Ave',
    status: 'pending',
    estimatedImplementationTime: '1 minute',
    aiReasoning: 'Event calendar integration and historical pattern analysis predict 40% traffic increase. Proactive timing adjustment recommended.'
  },
  {
    id: 'rec-003',
    type: 'alert',
    priority: 'high',
    title: 'Camera Malfunction Detection',
    description: 'Camera at Pine St & Center showing irregular patterns. Maintenance required.',
    impact: {
      timeReduction: 0,
      efficiencyGain: 5.5,
      costSaving: 800
    },
    confidence: 94,
    location: 'Pine St & Center',
    status: 'pending',
    estimatedImplementationTime: '30 minutes',
    aiReasoning: 'Computer vision analysis detected 15% reduction in detection accuracy over past 2 hours. Hardware inspection needed.'
  },
  {
    id: 'rec-004',
    type: 'optimization',
    priority: 'low',
    title: 'Implement Dynamic Pedestrian Timing',
    description: 'Enable adaptive pedestrian crossing times based on detected foot traffic.',
    impact: {
      timeReduction: 3.8,
      efficiencyGain: 7.2,
      costSaving: 600
    },
    confidence: 67,
    location: 'Main St & 1st Ave',
    status: 'applied',
    estimatedImplementationTime: '5 minutes',
    aiReasoning: 'Pedestrian flow analysis suggests 20% variance in crossing times. Dynamic adjustment could optimize overall intersection efficiency.'
  }
];

const aiInsights = [
  {
    title: 'Traffic Pattern Learning',
    description: 'AI has identified 12 new traffic patterns this week',
    status: 'active',
    accuracy: 94
  },
  {
    title: 'Predictive Modeling',
    description: 'Next hour congestion forecast accuracy improved by 8%',
    status: 'improving',
    accuracy: 87
  },
  {
    title: 'Optimization Engine',
    description: 'Signal timing optimizations reduced average wait time by 10%',
    status: 'successful',
    accuracy: 91
  }
];

export function AIRecommendations() {
  const [recommendations, setRecommendations] = useState(mockRecommendations);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedRecommendation, setSelectedRecommendation] = useState<string | null>(null);

  useEffect(() => {
    // Simulate AI generating new recommendations
    const interval = setInterval(() => {
      // Randomly update confidence scores or add new recommendations
      setRecommendations(prev => prev.map(rec => ({
        ...rec,
        confidence: Math.max(60, Math.min(99, rec.confidence + (Math.random() - 0.5) * 5))
      })));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const applyRecommendation = async (id: string) => {
    setIsProcessing(true);
    
    // Simulate AI implementation
    setTimeout(() => {
      setRecommendations(prev => prev.map(rec => 
        rec.id === id ? { ...rec, status: 'applied' } : rec
      ));
      setIsProcessing(false);
    }, 2000);
  };

  const rejectRecommendation = (id: string) => {
    setRecommendations(prev => prev.map(rec => 
      rec.id === id ? { ...rec, status: 'rejected' } : rec
    ));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'optimization': return <Zap className="w-4 h-4" />;
      case 'prediction': return <Target className="w-4 h-4" />;
      case 'alert': return <AlertTriangle className="w-4 h-4" />;
      case 'maintenance': return <Cpu className="w-4 h-4" />;
      default: return <Lightbulb className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'applied': return 'default';
      case 'rejected': return 'destructive';
      case 'pending': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      {/* AI System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5" />
              AI Traffic Management System
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsProcessing(true)}
              disabled={isProcessing}
            >
              <RefreshCw className={`w-4 h-4 ${isProcessing ? 'animate-spin' : ''}`} />
              Generate New Insights
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {aiInsights.map((insight, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{insight.title}</h4>
                  <Badge variant={
                    insight.status === 'successful' ? 'default' :
                    insight.status === 'improving' ? 'secondary' :
                    'outline'
                  }>
                    {insight.status}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{insight.description}</p>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Accuracy</span>
                    <span>{insight.accuracy}%</span>
                  </div>
                  <Progress value={insight.accuracy} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            AI Recommendations ({recommendations.filter(r => r.status === 'pending').length} pending)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.map((recommendation) => (
              <div
                key={recommendation.id}
                className={`border rounded-lg p-4 cursor-pointer transition-all hover:shadow-md ${
                  selectedRecommendation === recommendation.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedRecommendation(
                  selectedRecommendation === recommendation.id ? null : recommendation.id
                )}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      {getTypeIcon(recommendation.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium">{recommendation.title}</h4>
                        <Badge variant={getPriorityColor(recommendation.priority)}>
                          {recommendation.priority}
                        </Badge>
                        <Badge variant={getStatusColor(recommendation.status)}>
                          {recommendation.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {recommendation.description}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>📍 {recommendation.location}</span>
                        <span>⏱️ {recommendation.estimatedImplementationTime}</span>
                        <span>🎯 {recommendation.confidence}% confidence</span>
                      </div>
                    </div>
                  </div>
                  
                  {recommendation.status === 'pending' && (
                    <div className="flex gap-2 ml-4">
                      <Button
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          applyRecommendation(recommendation.id);
                        }}
                        disabled={isProcessing}
                      >
                        <CheckCircle className="w-4 h-4" />
                        Apply
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          rejectRecommendation(recommendation.id);
                        }}
                      >
                        Reject
                      </Button>
                    </div>
                  )}
                </div>

                {/* Impact Metrics */}
                <div className="grid grid-cols-3 gap-4 mb-3">
                  <div className="text-center p-2 bg-muted rounded">
                    <div className="text-lg font-bold text-green-600">
                      -{recommendation.impact.timeReduction}%
                    </div>
                    <div className="text-xs text-muted-foreground">Wait Time</div>
                  </div>
                  <div className="text-center p-2 bg-muted rounded">
                    <div className="text-lg font-bold text-blue-600">
                      +{recommendation.impact.efficiencyGain}%
                    </div>
                    <div className="text-xs text-muted-foreground">Efficiency</div>
                  </div>
                  <div className="text-center p-2 bg-muted rounded">
                    <div className="text-lg font-bold text-purple-600">
                      ${recommendation.impact.costSaving}
                    </div>
                    <div className="text-xs text-muted-foreground">Daily Savings</div>
                  </div>
                </div>

                {/* Confidence Meter */}
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>AI Confidence</span>
                    <span>{recommendation.confidence}%</span>
                  </div>
                  <Progress value={recommendation.confidence} className="h-2" />
                </div>

                {/* Expanded Details */}
                {selectedRecommendation === recommendation.id && (
                  <div className="mt-4 pt-4 border-t">
                    <h5 className="font-medium mb-2">AI Reasoning</h5>
                    <p className="text-sm text-muted-foreground bg-muted p-3 rounded">
                      {recommendation.aiReasoning}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            System Performance Impact
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-green-600 mb-1">-10.2%</div>
              <div className="text-sm text-muted-foreground">Average Commute Time</div>
              <div className="text-xs text-muted-foreground mt-1">Last 7 days</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-blue-600 mb-1">+15.8%</div>
              <div className="text-sm text-muted-foreground">Traffic Efficiency</div>
              <div className="text-xs text-muted-foreground mt-1">Since AI implementation</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-purple-600 mb-1">$12.4K</div>
              <div className="text-sm text-muted-foreground">Cost Savings</div>
              <div className="text-xs text-muted-foreground mt-1">This month</div>
            </div>
          </div>
          
          <div className="mt-4 flex gap-2">
            <Button variant="outline" size="sm">
              View Detailed Report
            </Button>
            <Button variant="outline" size="sm">
              Schedule Optimization
            </Button>
            <Button variant="outline" size="sm">
              Export Recommendations
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}