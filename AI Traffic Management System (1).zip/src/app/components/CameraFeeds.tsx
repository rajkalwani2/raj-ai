import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Camera, Maximize2, Play, Pause, RotateCcw } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CameraFeed {
  id: string;
  name: string;
  location: string;
  status: 'online' | 'offline' | 'maintenance';
  vehicleCount: number;
  congestionLevel: 'low' | 'medium' | 'high';
  lastUpdate: string;
}

const mockCameraFeeds: CameraFeed[] = [
  {
    id: 'cam-01',
    name: 'Main St & 1st Ave - North',
    location: 'Intersection A',
    status: 'online',
    vehicleCount: 12,
    congestionLevel: 'low',
    lastUpdate: '2s ago'
  },
  {
    id: 'cam-02',
    name: 'Broadway & 2nd Ave - East',
    location: 'Intersection B',
    status: 'online',
    vehicleCount: 28,
    congestionLevel: 'high',
    lastUpdate: '1s ago'
  },
  {
    id: 'cam-03',
    name: 'Oak St & 3rd Ave - South',
    location: 'Intersection C',
    status: 'online',
    vehicleCount: 15,
    congestionLevel: 'medium',
    lastUpdate: '3s ago'
  },
  {
    id: 'cam-04',
    name: 'Pine St & Center - West',
    location: 'Intersection D',
    status: 'maintenance',
    vehicleCount: 0,
    congestionLevel: 'low',
    lastUpdate: '5m ago'
  }
];

// Camera feed images based on traffic scenarios
const getCameraFeedImage = (feedId: string, congestionLevel: string) => {
  const images = {
    'cam-01': 'https://images.unsplash.com/photo-1682620949740-2dd9bd7dc867?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMHJvYWQlMjB0cmFmZmljJTIwZmxvdyUyMGNhcnN8ZW58MXx8fHwxNzU3NTg3MzUzfDA&ixlib=rb-4.1.0&q=80&w=1080', // Urban road with light traffic
    'cam-02': 'https://images.unsplash.com/photo-1702231945323-6e3d2153ab92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWdod2F5JTIwdHJhZmZpYyUyMGNvbmdlc3Rpb24lMjB2ZWhpY2xlc3xlbnwxfHx8fDE3NTc1ODczNDd8MA&ixlib=rb-4.1.0&q=80&w=1080', // Heavy congestion
    'cam-03': 'https://images.unsplash.com/photo-1724301487169-37d53089bcdb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwc3RyZWV0JTIwdHJhZmZpYyUyMGxpZ2h0JTIwaW50ZXJzZWN0aW9ufGVufDF8fHx8MTc1NzU4NzM1MHww&ixlib=rb-4.1.0&q=80&w=1080', // City intersection
    'cam-04': 'https://images.unsplash.com/photo-1556806805-a620cc7f32f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXN5JTIwdXJiYW4lMjBpbnRlcnNlY3Rpb24lMjB0cmFmZmljJTIwY2Fyc3xlbnwxfHx8fDE3NTc1ODczNDN8MA&ixlib=rb-4.1.0&q=80&w=1080'  // Busy intersection
  };
  return images[feedId as keyof typeof images] || images['cam-01'];
};

export function CameraFeeds() {
  const [feeds, setFeeds] = useState(mockCameraFeeds);
  const [selectedFeed, setSelectedFeed] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    // Simulate real-time vehicle count updates
    const interval = setInterval(() => {
      setFeeds(prev => prev.map(feed => ({
        ...feed,
        vehicleCount: feed.status === 'online' ? 
          Math.max(0, feed.vehicleCount + Math.floor((Math.random() - 0.5) * 8)) : 0,
        congestionLevel: feed.vehicleCount > 25 ? 'high' : 
                        feed.vehicleCount > 15 ? 'medium' : 'low',
        lastUpdate: feed.status === 'online' ? `${Math.floor(Math.random() * 5) + 1}s ago` : feed.lastUpdate
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'default';
      case 'offline': return 'destructive';
      case 'maintenance': return 'secondary';
      default: return 'outline';
    }
  };

  const getCongestionColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-sky-50 to-cyan-50 border-sky-200 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sky-700">
              <div className="p-2 bg-sky-500 rounded-lg">
                <Camera className="w-5 h-5 text-white" />
              </div>
              Live Camera Feeds
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setIsPlaying(!isPlaying)}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isPlaying ? 'Pause' : 'Play'}
              </Button>
              <Button size="sm" variant="outline">
                <RotateCcw className="w-4 h-4" />
                Refresh All
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {feeds.map((feed) => (
              <div
                key={feed.id}
                className={`border rounded-lg p-4 cursor-pointer transition-all hover:shadow-lg hover:scale-105 bg-white/80 backdrop-blur-sm ${
                  selectedFeed === feed.id ? 'ring-2 ring-sky-500 shadow-lg' : 'border-sky-200'
                }`}
                onClick={() => setSelectedFeed(selectedFeed === feed.id ? null : feed.id)}
              >
                {/* Camera Feed Placeholder */}
                <div className="relative mb-3">
                  <div className="aspect-video bg-gray-900 rounded overflow-hidden flex items-center justify-center">
                    {feed.status === 'online' ? (
                      <div className="relative w-full h-full">
                        <ImageWithFallback
                          src={getCameraFeedImage(feed.id, feed.congestionLevel)}
                          alt={`Traffic camera feed for ${feed.name}`}
                          className="w-full h-full object-cover"
                        />
                        {/* Traffic Monitoring Overlay */}
                        <div className="absolute inset-0">
                          {/* Vehicle Detection Boxes */}
                          {feed.congestionLevel !== 'low' && (
                            <>
                              <div className="absolute top-16 left-8 w-12 h-8 border-2 border-green-400 bg-green-400/20">
                                <div className="absolute -top-5 left-0 text-xs text-green-400 font-semibold">CAR</div>
                              </div>
                              <div className="absolute top-20 right-12 w-16 h-10 border-2 border-yellow-400 bg-yellow-400/20">
                                <div className="absolute -top-5 left-0 text-xs text-yellow-400 font-semibold">TRUCK</div>
                              </div>
                              {feed.congestionLevel === 'high' && (
                                <>
                                  <div className="absolute bottom-16 left-16 w-10 h-6 border-2 border-blue-400 bg-blue-400/20">
                                    <div className="absolute -top-5 left-0 text-xs text-blue-400 font-semibold">CAR</div>
                                  </div>
                                  <div className="absolute top-12 left-24 w-14 h-8 border-2 border-purple-400 bg-purple-400/20">
                                    <div className="absolute -top-5 left-0 text-xs text-purple-400 font-semibold">VAN</div>
                                  </div>
                                </>
                              )}
                            </>
                          )}
                          
                          {/* Status and Data Overlays */}
                          <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-semibold animate-pulse flex items-center gap-1">
                            <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                            LIVE
                          </div>
                          
                          <div className="absolute top-2 right-2 space-y-1">
                            <div className="bg-blue-600 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
                              🚗 {feed.vehicleCount} vehicles
                            </div>
                            <div className={`text-white px-2 py-1 rounded text-xs ${
                              feed.congestionLevel === 'high' ? 'bg-red-600' :
                              feed.congestionLevel === 'medium' ? 'bg-yellow-600' : 'bg-green-600'
                            }`}>
                              {feed.congestionLevel.toUpperCase()} TRAFFIC
                            </div>
                          </div>
                          
                          <div className="absolute bottom-2 left-2 bg-slate-900/80 text-white px-2 py-1 rounded text-xs backdrop-blur-sm">
                            📅 {new Date().toLocaleTimeString()}
                          </div>
                          
                          <div className="absolute bottom-2 right-2 bg-slate-900/80 text-white px-2 py-1 rounded text-xs backdrop-blur-sm">
                            📍 {feed.location}
                          </div>
                          
                          {/* Speed Detection */}
                          <div className="absolute bottom-8 left-2 bg-orange-600 text-white px-2 py-1 rounded text-xs">
                            ⚡ {Math.floor(Math.random() * 30) + 15} km/h avg
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-gray-400 text-center">
                        <Camera className="w-12 h-12 mx-auto mb-2" />
                        <div>Camera {feed.status}</div>
                      </div>
                    )}
                  </div>
                  
                  {/* Expand button */}
                  <Button
                    size="sm"
                    variant="secondary"
                    className="absolute top-2 right-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Handle fullscreen view
                    }}
                  >
                    <Maximize2 className="w-4 h-4" />
                  </Button>
                </div>

                {/* Feed Info */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium truncate">{feed.name}</h4>
                    <Badge variant={getStatusColor(feed.status)}>
                      {feed.status}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{feed.location}</span>
                    <span className="text-muted-foreground">{feed.lastUpdate}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Vehicles:</span>
                      <Badge variant="outline">{feed.vehicleCount}</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Congestion:</span>
                      <span className={`px-2 py-1 rounded-full text-xs ${getCongestionColor(feed.congestionLevel)}`}>
                        {feed.congestionLevel}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Detailed View */}
      {selectedFeed && (
        <Card className="bg-gradient-to-br from-slate-50 to-slate-100 border-slate-200 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-slate-700">
              <div className="p-2 bg-slate-600 rounded-lg">
                <Camera className="w-5 h-5 text-white" />
              </div>
              Detailed Analysis - {feeds.find(f => f.id === selectedFeed)?.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-blue-600">Vehicle Detection</h4>
                    <div className="text-2xl font-bold text-blue-900">
                      {feeds.find(f => f.id === selectedFeed)?.vehicleCount}
                    </div>
                    <div className="text-xs text-blue-600">
                      🚗 Cars: {Math.floor((feeds.find(f => f.id === selectedFeed)?.vehicleCount || 0) * 0.8)}
                    </div>
                    <div className="text-xs text-blue-600">
                      🚛 Trucks: {Math.floor((feeds.find(f => f.id === selectedFeed)?.vehicleCount || 0) * 0.2)}
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-green-600">Queue Length</h4>
                    <div className="text-2xl font-bold text-green-900">
                      {Math.floor(Math.random() * 50) + 10}m
                    </div>
                    <div className="text-xs text-green-600">
                      Max today: {Math.floor(Math.random() * 30) + 40}m
                    </div>
                    <div className="text-xs text-green-600">
                      Avg: {Math.floor(Math.random() * 20) + 15}m
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-purple-600">Flow Rate</h4>
                    <div className="text-2xl font-bold text-purple-900">
                      {Math.floor(Math.random() * 200) + 100}
                    </div>
                    <div className="text-xs text-purple-600">
                      Vehicles per hour
                    </div>
                    <div className="text-xs text-purple-600">
                      Peak: {Math.floor(Math.random() * 100) + 250}/hr
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-orange-600">Average Speed</h4>
                    <div className="text-2xl font-bold text-orange-900">
                      {Math.floor(Math.random() * 25) + 15} km/h
                    </div>
                    <div className="text-xs text-orange-600">
                      Speed limit: 50 km/h
                    </div>
                    <div className="text-xs text-orange-600">
                      Compliance: {Math.floor(Math.random() * 20) + 75}%
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* AI Detection Results */}
            <Card className="mb-4 bg-gradient-to-br from-indigo-50 to-indigo-100 border-indigo-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-indigo-700">
                  <div className="p-1 bg-indigo-500 rounded">
                    <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
                  </div>
                  AI Detection Results
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <h5 className="font-medium text-indigo-600">Object Detection</h5>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>🚗 Vehicles:</span>
                        <span className="font-semibold">{feeds.find(f => f.id === selectedFeed)?.vehicleCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>👥 Pedestrians:</span>
                        <span className="font-semibold">{Math.floor(Math.random() * 8) + 2}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>🚴 Cyclists:</span>
                        <span className="font-semibold">{Math.floor(Math.random() * 3)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h5 className="font-medium text-indigo-600">Traffic Violations</h5>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>🚫 Red Light:</span>
                        <span className="font-semibold text-red-600">{Math.floor(Math.random() * 3)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>⚡ Speeding:</span>
                        <span className="font-semibold text-orange-600">{Math.floor(Math.random() * 5)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>🚗 Wrong Lane:</span>
                        <span className="font-semibold text-yellow-600">{Math.floor(Math.random() * 2)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h5 className="font-medium text-indigo-600">Safety Metrics</h5>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>🔒 Safety Score:</span>
                        <span className="font-semibold text-green-600">{Math.floor(Math.random() * 20) + 75}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>⚠️ Incidents:</span>
                        <span className="font-semibold">{Math.floor(Math.random() * 2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>🚨 Alerts:</span>
                        <span className="font-semibold text-amber-600">{Math.floor(Math.random() * 4)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100">
                📥 Download Recording
              </Button>
              <Button size="sm" variant="outline" className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100">
                🚨 Report Issue
              </Button>
              <Button size="sm" variant="outline" className="bg-green-50 border-green-200 text-green-700 hover:bg-green-100">
                📤 Share View
              </Button>
              <Button size="sm" variant="outline" className="bg-purple-50 border-purple-200 text-purple-700 hover:bg-purple-100">
                🎯 Track Object
              </Button>
              <Button size="sm" variant="outline" className="bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100">
                📊 Export Data
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}