import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { 
  Bell, 
  AlertTriangle, 
  Info, 
  CheckCircle, 
  XCircle, 
  Clock,
  MapPin,
  Eye,
  EyeOff,
  Trash2,
  Filter
} from 'lucide-react';

interface Alert {
  id: string;
  type: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  location: string;
  timestamp: Date;
  isRead: boolean;
  isActive: boolean;
  priority: 'high' | 'medium' | 'low';
  source: 'ai' | 'sensor' | 'camera' | 'manual';
  actionRequired: boolean;
  estimatedResolutionTime?: string;
}

const generateMockAlerts = (): Alert[] => {
  const alertTypes = ['critical', 'warning', 'info'] as const;
  const priorities = ['high', 'medium', 'low'] as const;
  const sources = ['ai', 'sensor', 'camera', 'manual'] as const;
  const locations = [
    'Main St & 1st Ave',
    'Broadway & 2nd Ave',
    'Oak St & 3rd Ave',
    'Pine St & Center',
    'Elm St & Park Ave'
  ];

  const alertTemplates = [
    {
      title: 'Heavy Traffic Congestion Detected',
      description: 'Unusual traffic buildup detected, queue length exceeding normal parameters',
      actionRequired: true
    },
    {
      title: 'Signal Timing Optimization Available',
      description: 'AI has identified potential 15% efficiency improvement',
      actionRequired: false
    },
    {
      title: 'Camera Feed Disconnected',
      description: 'Traffic monitoring camera has lost connection',
      actionRequired: true
    },
    {
      title: 'Emergency Vehicle Detected',
      description: 'Emergency vehicle approaching intersection, priority routing activated',
      actionRequired: false
    },
    {
      title: 'Pedestrian Safety Alert',
      description: 'Unusual pedestrian activity detected outside crosswalk zones',
      actionRequired: true
    },
    {
      title: 'Weather Impact on Traffic',
      description: 'Rain conditions affecting traffic flow, adaptive timing recommended',
      actionRequired: false
    },
    {
      title: 'System Performance Degradation',
      description: 'Signal response time increased by 20% over last hour',
      actionRequired: true
    }
  ];

  return Array.from({ length: 15 }, (_, index) => {
    const template = alertTemplates[Math.floor(Math.random() * alertTemplates.length)];
    const type = alertTypes[Math.floor(Math.random() * alertTypes.length)];
    const timestamp = new Date(Date.now() - Math.random() * 86400000); // Random time in last 24h
    
    return {
      id: `alert-${index + 1}`,
      type,
      title: template.title,
      description: template.description,
      location: locations[Math.floor(Math.random() * locations.length)],
      timestamp,
      isRead: Math.random() > 0.6,
      isActive: Math.random() > 0.3,
      priority: priorities[Math.floor(Math.random() * priorities.length)],
      source: sources[Math.floor(Math.random() * sources.length)],
      actionRequired: template.actionRequired,
      estimatedResolutionTime: template.actionRequired ? `${Math.floor(Math.random() * 30) + 5} minutes` : undefined
    };
  }).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
};

export function AlertSystem() {
  const [alerts, setAlerts] = useState<Alert[]>(generateMockAlerts());
  const [filter, setFilter] = useState<'all' | 'unread' | 'active' | 'critical'>('all');
  const [newAlertsCount, setNewAlertsCount] = useState(0);

  useEffect(() => {
    // Simulate new alerts coming in
    const interval = setInterval(() => {
      if (Math.random() > 0.7) { // 30% chance every 10 seconds
        const newAlert = generateMockAlerts()[0];
        newAlert.id = `alert-${Date.now()}`;
        newAlert.timestamp = new Date();
        newAlert.isRead = false;
        newAlert.isActive = true;
        
        setAlerts(prev => [newAlert, ...prev]);
        setNewAlertsCount(prev => prev + 1);
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const filteredAlerts = alerts.filter(alert => {
    switch (filter) {
      case 'unread': return !alert.isRead;
      case 'active': return alert.isActive;
      case 'critical': return alert.type === 'critical';
      default: return true;
    }
  });

  const markAsRead = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, isRead: true } : alert
    ));
    if (newAlertsCount > 0) {
      setNewAlertsCount(prev => prev - 1);
    }
  };

  const markAllAsRead = () => {
    setAlerts(prev => prev.map(alert => ({ ...alert, isRead: true })));
    setNewAlertsCount(0);
  };

  const dismissAlert = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, isActive: false } : alert
    ));
  };

  const deleteAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'info': return <Info className="w-4 h-4 text-blue-500" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  const getAlertBadgeVariant = (type: string) => {
    switch (type) {
      case 'critical': return 'destructive';
      case 'warning': return 'secondary';
      case 'info': return 'outline';
      default: return 'outline';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'ai': return '🤖';
      case 'sensor': return '📡';
      case 'camera': return '📹';
      case 'manual': return '👤';
      default: return '🔔';
    }
  };

  const formatTimeAgo = (timestamp: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - timestamp.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  return (
    <div className="space-y-4">
      {/* Alert Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Alert System
              {newAlertsCount > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {newAlertsCount} new
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={markAllAsRead}>
                <CheckCircle className="w-4 h-4" />
                Mark All Read
              </Button>
              <Button size="sm" variant="outline">
                <Filter className="w-4 h-4" />
                Export Alerts
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center p-3 border rounded-lg">
              <div className="text-2xl font-bold text-red-600">
                {alerts.filter(a => a.type === 'critical' && a.isActive).length}
              </div>
              <div className="text-sm text-muted-foreground">Critical</div>
            </div>
            <div className="text-center p-3 border rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">
                {alerts.filter(a => a.type === 'warning' && a.isActive).length}
              </div>
              <div className="text-sm text-muted-foreground">Warnings</div>
            </div>
            <div className="text-center p-3 border rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {alerts.filter(a => a.type === 'info' && a.isActive).length}
              </div>
              <div className="text-sm text-muted-foreground">Info</div>
            </div>
            <div className="text-center p-3 border rounded-lg">
              <div className="text-2xl font-bold">
                {alerts.filter(a => !a.isRead).length}
              </div>
              <div className="text-sm text-muted-foreground">Unread</div>
            </div>
          </div>

          {/* Filter Buttons */}
          <div className="flex gap-2">
            <Button
              size="sm"
              variant={filter === 'all' ? 'default' : 'outline'}
              onClick={() => setFilter('all')}
            >
              All ({alerts.length})
            </Button>
            <Button
              size="sm"
              variant={filter === 'unread' ? 'default' : 'outline'}
              onClick={() => setFilter('unread')}
            >
              Unread ({alerts.filter(a => !a.isRead).length})
            </Button>
            <Button
              size="sm"
              variant={filter === 'active' ? 'default' : 'outline'}
              onClick={() => setFilter('active')}
            >
              Active ({alerts.filter(a => a.isActive).length})
            </Button>
            <Button
              size="sm"
              variant={filter === 'critical' ? 'default' : 'outline'}
              onClick={() => setFilter('critical')}
            >
              Critical ({alerts.filter(a => a.type === 'critical').length})
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Alert List */}
      <Card>
        <CardHeader>
          <CardTitle>
            Alert Feed ({filteredAlerts.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-96">
            <div className="p-4 space-y-3">
              {filteredAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`border rounded-lg p-4 transition-all hover:shadow-md ${
                    !alert.isRead ? 'border-l-4 border-l-blue-500 bg-blue-50/50' : ''
                  } ${!alert.isActive ? 'opacity-60' : ''}`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="mt-1">
                        {getAlertIcon(alert.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className={`font-medium ${!alert.isRead ? 'font-semibold' : ''}`}>
                            {alert.title}
                          </h4>
                          <Badge variant={getAlertBadgeVariant(alert.type)}>
                            {alert.type}
                          </Badge>
                          {alert.priority === 'high' && (
                            <Badge variant="destructive" className="text-xs">
                              High Priority
                            </Badge>
                          )}
                          {alert.actionRequired && (
                            <Badge variant="secondary" className="text-xs">
                              Action Required
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {alert.description}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {alert.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatTimeAgo(alert.timestamp)}
                          </span>
                          <span>
                            {getSourceIcon(alert.source)} {alert.source}
                          </span>
                          {alert.estimatedResolutionTime && (
                            <span>⏱️ {alert.estimatedResolutionTime}</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1 ml-4">
                      {!alert.isRead && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => markAsRead(alert.id)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      )}
                      {alert.isActive && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => dismissAlert(alert.id)}
                        >
                          <EyeOff className="w-4 h-4" />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteAlert(alert.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {alert.actionRequired && alert.isActive && (
                    <div className="mt-3 pt-3 border-t">
                      <div className="flex gap-2">
                        <Button size="sm" variant="default">
                          Take Action
                        </Button>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                        <Button size="sm" variant="outline">
                          Escalate
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              
              {filteredAlerts.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No alerts match the current filter.</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}