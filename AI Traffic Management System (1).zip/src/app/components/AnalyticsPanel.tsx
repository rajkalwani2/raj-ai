import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  Clock, 
  Car, 
  AlertCircle,
  Download,
  Calendar
} from 'lucide-react';

// Mock data for charts
const generateTimeSeriesData = (hours: number) => {
  const data = [];
  const now = new Date();
  
  for (let i = hours; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 60 * 60 * 1000);
    data.push({
      time: time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      trafficFlow: Math.floor(Math.random() * 200) + 50,
      averageWaitTime: Math.random() * 8 + 1,
      congestionLevel: Math.random() * 100,
      efficiency: Math.random() * 40 + 60
    });
  }
  return data;
};

const intersectionData = [
  { name: 'Main St & 1st Ave', efficiency: 87, volume: 1250, incidents: 0 },
  { name: 'Broadway & 2nd Ave', efficiency: 72, volume: 1820, incidents: 2 },
  { name: 'Oak St & 3rd Ave', efficiency: 45, volume: 2100, incidents: 5 },
  { name: 'Pine St & Center', efficiency: 92, volume: 980, incidents: 0 },
  { name: 'Elm St & Park Ave', efficiency: 78, volume: 1560, incidents: 1 }
];

const vehicleTypeData = [
  { name: 'Cars', value: 68, color: '#3b82f6' },
  { name: 'Trucks', value: 15, color: '#ef4444' },
  { name: 'Buses', value: 8, color: '#10b981' },
  { name: 'Motorcycles', value: 6, color: '#f59e0b' },
  { name: 'Other', value: 3, color: '#8b5cf6' }
];

const performanceMetrics = [
  {
    title: 'Average Commute Time',
    value: '23.4 min',
    change: -8.2,
    trend: 'down',
    target: '25.0 min'
  },
  {
    title: 'Traffic Efficiency',
    value: '78.6%',
    change: 12.3,
    trend: 'up',
    target: '80.0%'
  },
  {
    title: 'Signal Uptime',
    value: '99.2%',
    change: 0.8,
    trend: 'up',
    target: '99.5%'
  },
  {
    title: 'Incidents Resolved',
    value: '94.1%',
    change: -2.1,
    trend: 'down',
    target: '95.0%'
  }
];

export function AnalyticsPanel() {
  const [timeSeriesData, setTimeSeriesData] = useState(() => generateTimeSeriesData(24));
  const [selectedTimeRange, setSelectedTimeRange] = useState('24h');

  useEffect(() => {
    // Simulate real-time data updates
    const interval = setInterval(() => {
      const hours = selectedTimeRange === '1h' ? 1 : selectedTimeRange === '6h' ? 6 : 24;
      setTimeSeriesData(generateTimeSeriesData(hours));
    }, 5000);

    return () => clearInterval(interval);
  }, [selectedTimeRange]);

  return (
    <div className="space-y-6">
      {/* Performance Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Performance Overview
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline">
                <Download className="w-4 h-4" />
                Export Report
              </Button>
              <Button size="sm" variant="outline">
                <Calendar className="w-4 h-4" />
                Custom Range
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {performanceMetrics.map((metric, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">{metric.title}</span>
                  {metric.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-500" />
                  )}
                </div>
                <div className="text-2xl font-bold mb-1">{metric.value}</div>
                <div className="flex items-center justify-between text-sm">
                  <span className={`flex items-center gap-1 ${
                    metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {metric.change > 0 ? '+' : ''}{metric.change.toFixed(1)}%
                  </span>
                  <span className="text-muted-foreground">Target: {metric.target}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Time Series Analytics */}
      <Card>
        <CardHeader>
          <CardTitle>Real-time Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
            <TabsList className="mb-4">
              <TabsTrigger value="1h">Last Hour</TabsTrigger>
              <TabsTrigger value="6h">Last 6 Hours</TabsTrigger>
              <TabsTrigger value="24h">Last 24 Hours</TabsTrigger>
            </TabsList>
            
            <TabsContent value={selectedTimeRange} className="space-y-4">
              {/* Traffic Flow Chart */}
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Car className="w-4 h-4" />
                  Traffic Flow (Vehicles per Hour)
                </h4>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="trafficFlow"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Wait Time and Efficiency */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Average Wait Time (minutes)
                  </h4>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="averageWaitTime"
                        stroke="#ef4444"
                        strokeWidth={2}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div>
                  <h4 className="font-medium mb-2">System Efficiency (%)</h4>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Area
                        type="monotone"
                        dataKey="efficiency"
                        stroke="#10b981"
                        fill="#10b981"
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Intersection Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Intersection Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={intersectionData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" domain={[0, 100]} />
                <YAxis dataKey="name" type="category" width={120} />
                <Tooltip />
                <Bar dataKey="efficiency" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Vehicle Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={vehicleTypeData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {vehicleTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Intersection Table */}
      <Card>
        <CardHeader>
          <CardTitle>Intersection Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Intersection</th>
                  <th className="text-left p-2">Efficiency</th>
                  <th className="text-left p-2">Volume (24h)</th>
                  <th className="text-left p-2">Incidents</th>
                  <th className="text-left p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {intersectionData.map((intersection, index) => (
                  <tr key={index} className="border-b hover:bg-muted/50">
                    <td className="p-2">{intersection.name}</td>
                    <td className="p-2">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 bg-gray-200 rounded">
                          <div
                            className="h-2 bg-blue-500 rounded"
                            style={{ width: `${intersection.efficiency}%` }}
                          />
                        </div>
                        <span>{intersection.efficiency}%</span>
                      </div>
                    </td>
                    <td className="p-2">{intersection.volume.toLocaleString()}</td>
                    <td className="p-2">
                      {intersection.incidents > 0 ? (
                        <Badge variant="destructive" className="flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {intersection.incidents}
                        </Badge>
                      ) : (
                        <Badge variant="default">0</Badge>
                      )}
                    </td>
                    <td className="p-2">
                      <Badge variant={
                        intersection.efficiency > 85 ? 'default' :
                        intersection.efficiency > 70 ? 'secondary' :
                        'destructive'
                      }>
                        {intersection.efficiency > 85 ? 'Optimal' :
                         intersection.efficiency > 70 ? 'Good' :
                         'Needs Attention'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}